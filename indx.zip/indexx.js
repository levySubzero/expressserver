var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var socketioJwt = require('socketio-jwt');
var mysql = require('mysql');
var crypto = require('crypto');
var path = require('path');
var clonedeep = require('lodash.clonedeep');
var cors = require('cors');

app.use(cors({
	origin: 'http://localhost:3000',
	methods: ['GET', 'POST']
}));


// loading configuration from .env
require('dotenv').config();
var connection;
var port = process.env.PORT || 3000;
var is_redis = false;

if (process.env.REDIS_ENDPOINT) {
	console.log('redis');
	var redis = require('socket.io-redis');
	io.adapter(redis({ host: process.env.REDIS_ENDPOINT, port: 6379 }));
	is_redis = true;
}

function handleDisconnect() {
	connection = mysql.createConnection({
		host: process.env.DB_HOST_WRITE,
		port: process.env.DB_PORT,
		user: process.env.DB_USERNAME,
		password: process.env.DB_PASSWORD,
		database: process.env.DB_DATABASE
	});

	connection.connect(function (err) {
		if (err) {
			console.log(new Date().toUTCString() + ': could not connect to DB. Reconnecting in 2 seconds');
			setTimeout(handleDisconnect, 2000);
		}
	});
	connection.on('error', function (err) {
		if (err.code === 'PROTOCOL_CONNECTION_LOST') {
			console.log(new Date().toUTCString() + ': db connection loss. Instant reconnect.');
			handleDisconnect();
		} else {
			throw err;
		}
	});
}

handleDisconnect();

io.use(socketioJwt.authorize({
	secret: process.env.JWT_SECRET,
	handshake: true
}));

// just the homepage for health checks
app.use(express.static(path.join(__dirname, 'public')));

// game vars
var game_is_on = false;
var game_settings;
var game_question;
var game_answers_stats = {};
var game_winners = [];
var game_interval;
var game_lives = {};
var analytics = {};
var reconnect_timeout;

// custom hook to handle local variables updates via redis
io.of('/').adapter.customHook = (data, cb) => {
	switch (data.type) {
		case 'settings':
			m_settings(data.settings);
			cb(true);
			break;
		case 'stats':
			cb(m_stats());
			break;
		case 'start':
			m_start();
			cb(true);
			break;
		case 'question':
			m_question(data.question, data.correct, data.hash);
			cb(true);
			break;
		case 'correct':
			cb(m_correct());
			break;
		case 'winners':
			cb(m_winners());
			break;
		case 'lives':
			cb(m_lives());
			break;
		case 'stop':
			m_stop();
			cb(true);
			break;
		case 'force-end':
			m_force_end();
			cb(true);
			break;
		case 'reconnect':
			m_reconnect();
			cb(true);
			break;
	}
}

io.on('connection', function (socket) {

	console.log('made connection!!!');
	// moderator
	if (socket.decoded_token.moderator) {
		// moderator has to be validated in DB additionally
		connection.query('SELECT * FROM players WHERE id=? LIMIT 1', [socket.decoded_token.id], function (error, results) {
			if (error) {
				console.log(new Date().toUTCString() + ": " + error);
				socket.disconnect(true);
				return;
			}

			if (results.length < 1 || results[0].channel_type != 'moderator') {
				console.log(new Date().toUTCString() + ": Not a valid moderator account.");
				socket.disconnect(true);
				return;
			}
		});

		if (socket.handshake.query.resume) {
			console.log(new Date().toUTCString() + ": moderator reconnected.");
			clearTimeout(reconnect_timeout);
			if (reconnect_timeout === true) {
				if (is_redis) {
					// load players data from DB
					io.of('/').adapter.customRequest({ type: 'reconnect' }, function (err, replies) {
						if (err)
							console.log('could not set players data from DB: ' + err);
					});
				} else {
					m_reconnect();
				}
			}
		}

		// save settings
		socket.on('mod-settings', function (settings) {
			if (is_redis) {
				// set settings in all nodes
				io.of('/').adapter.customRequest({ type: 'settings', settings: settings }, function (err, replies) {
					if (err)
						console.log('could not set game settings in all nodes: ' + err);
				});
			} else {
				m_settings(settings);
			}
		});

		// start the show
		socket.on('mod-start', function () {
			// set interval function, that sends updated info on number of connections
			game_interval = setInterval(m_send_stats, 1000);
			// analytics
			analytics = {
				seconds: [],
				questions: [],
				answered_correctly: {},
				times: {
					start: new Date().toISOString(),
					questions: {}
				}
			};

			if (is_redis) {
				// set settings in all nodes
				io.of('/').adapter.customRequest({ type: 'start' }, function (err, replies) {
					if (err)
						console.log('could not set game start in all nodes: ' + err);
				});
			} else {
				m_start();
			}
		});

		// random shoutouts
		socket.on('mod-shoutouts', function (callback) {
			var shoutouts = [];
			var sockets = io.sockets.sockets;
			var limit = 25;
			for (var socketId in sockets) {
				var s = sockets[socketId];
				if (s.player) {
					shoutouts.push(s.player);
				}
				if (shoutouts.length >= limit) {
					break;
				}
			}
			callback(shoutouts);
		});

		// received new question
		socket.on('mod-question', function (question, correct) {
			question.islast = question.game_order === game_settings.game.questions;
			var hash = crypto.randomBytes(16).toString('hex');

			if (is_redis) {
				io.of('/').adapter.customRequest({ type: 'question', question: question, correct: correct, hash: hash }, function (err, replies) {
					if (err)
						console.log('could not send question to all nodes: ' + err);
					doCallback(question);
				});
			} else {
				m_question(question, correct, hash);
				doCallback(question);
			}

			function doCallback(question) {
				io.emit('question', question);
				analytics.times.questions[question.game_order] = {
					asked: new Date().toISOString(),
				};
				analytics.answered_correctly[game_question.game_order] = [];
			}
		});
		// send correct answer to players and return answers stats
		socket.on('mod-correct', function (callback) {
			if (is_redis) {
				io.of('/').adapter.customRequest({ type: 'correct' }, function (err, replies) {
					if (err)
						console.log('could not get answers stats from all nodes: ' + err);
					else {
						var the_game_answers_stats = {};

						for (var j in replies) {
							for (var i in game_question.answers) {
								var a = game_question.answers[i];
								if (!the_game_answers_stats.hasOwnProperty(a.id)) {
									the_game_answers_stats[a.id] = 0;
								}
								the_game_answers_stats[a.id] += replies[j][a.id];
							}
						}
						doCallback(game_question.correct, the_game_answers_stats);
					}
				});
			} else {
				doCallback(game_question.correct, m_correct());
			}

			function doCallback(correct, stats) {
				io.emit('correct', correct, stats);
				callback(stats);

				var stats = {
					question: game_question.id,
					stats: stats,
					lives: 0
				};

				analytics.questions.push(stats);
				analytics.times.questions[game_question.game_order].correct = new Date().toISOString();
				/////
				connection.query("UPDATE games SET analytics=? WHERE id=?", [JSON.stringify(analytics), game_settings.game.id], function (error, results) {
					if (error)
						console.log(error);
				});
			}
		});
		// force end
		socket.on('mod-force-end', function (callback) {
			if (is_redis) {
				io.of('/').adapter.customRequest({ type: 'force-end' }, function (err, replies) {
					if (err)
						console.log('could not get force end from all nodes: ' + err);
					else {
						callback();
					}
				});
			} else {
				m_force_end();
				callback();
			}
		});
		// get winners
		socket.on('mod-winners', function (callback) {
			if (is_redis) {
				io.of('/').adapter.customRequest({ type: 'winners' }, function (err, replies) {
					if (err)
						console.log('could not get winners from all nodes: ' + err);
					else {
						var the_game_winners = [];
						for (var i in replies) {
							the_game_winners = the_game_winners.concat(replies[i]);
						}
						doCallback(the_game_winners);
					}
				});
			} else {
				doCallback(m_winners());
			}

			function doCallback(winners) {
				var amount = winners.length > 0 ? Math.round(game_settings.game.amount / winners.length * 100) : 0
				callback(amount, winners);
				setTimeout(function () {
					io.emit('winners', amount, winners);
				}, game_settings['video-delay']);
				m_save_winners(amount, winners);
			}
		});
		// stop the game
		socket.on('disconnect', function () {
			console.log(new Date().toUTCString() + ": moderator has disconnected. Waiting 600 seconds to verify it's not an accident.");
			// we need to make sure it's not a loss of connection
			// so we will actually stop the game after 600 seconds
			reconnect_timeout = setTimeout(function () {
				console.log(new Date().toUTCString() + ": moderator has fully disconnected (600 seconds has passed since disconnect event). Disconnecing all users.");
				clearInterval(game_interval);

				if (is_redis) {
					io.of('/').adapter.customRequest({ type: 'stop' }, function (err, replies) {
						if (err)
							console.log('could not set game stop in all nodes: ' + err);
					});
				} else {
					m_stop();
				}

				setTimeout(function () {
					io.emit('end');
					if (analytics.times) {
						analytics.times.end = new Date().toISOString();
						m_analytics_save();
					}
				}, game_settings['video-delay']);
			}, process.env.MAX_RECONNECT_TIME * 1000);
		});
		// write analytics
		socket.on('mod-analytics', function (what) {
			analytics.times[what] = new Date().toISOString();
		});

	}
	// normal player
	else {
		// allow connection only when the show is running
		if (!game_is_on) {
			socket.disconnect(true);
			return;
		} else {

			var sockets = io.sockets.sockets;
			for (var socketId in sockets) {
				var s = sockets[socketId];
				if (s.player && s.player.id == socket.decoded_token.id) {
					socket.emit('socket-exists');
					socket.disconnect(true);
					return;
				}
			}


			socket.player = {
				id: socket.decoded_token.id,
				username: socket.decoded_token.username !== null ? socket.decoded_token.username : "",
				avatar: socket.decoded_token.avatar !== null ? socket.decoded_token.avatar : "",
				lives_used: 0
			};


			if (game_question == null) {
				kickIn(1);
			} else {
				// user has 5 seconds to provide question hash, or they will be "watching only"
				socket.player.reconnect_timeout = setTimeout(function () {
					kickOut();
				}, 5000);
			}

			function kickIn(question) {
				socket.player_question = question;
				socket.player_is_playing = true;
				socket.emit('settings', {
					counter: game_settings.game.counter
				});
			}

			function kickOut() {
				socket.player_question = 0;
				socket.player_is_playing = false;
				socket.emit('watch');
			}

			// verify re-connect hash
			socket.on('hash', function (hash) {
				clearTimeout(socket.player.reconnect_timeout);
				if (game_question != null) {
					var expected = crypto.createHash('md5').update(game_question.hash + socket.player.id).digest("hex");
					if (expected == hash) {
						kickIn(game_question.game_order + 1);
					} else {
						kickOut();
					}
				}
			});

			// player answers question
			socket.on('answer', function (answer, callback) {
				// question hash random - means incorrect
				var hash = crypto.createHash('md5').update(crypto.randomBytes(16)).digest("hex");
				// current time
				var date = new Date();


				// seconds from moment when question was asked and answered
				var diff = (date.getTime() - game_question.asked.getTime()) / 1000;
				// check if player is in the game, answering current question and did it in proper time + 2 seconds for data transfer
				if (socket.player_is_playing
					&& socket.player_question == game_question.game_order
					&& diff < game_settings['answer-time'] + 2) {
					// update answers stats
					game_answers_stats[answer]++;
					// check answer
					if (answer == game_question.correct) {
						// give user the right hash
						hash = crypto.createHash('md5').update(game_question.hash + socket.player.id).digest("hex");
						// is this the last question - user is a winner
						if (game_question.islast) {
							game_winners.push(socket.player);
						}
						// or moving user on to the next question
						else {
							socket.player_question++;
						}
						////////     add player id to analytics for troubleshoot
						analytics.answered_correctly[game_question.game_order].push(socket.player.id);
					}
					// wrong answer - kick out of the game
					else {
						socket.player_is_playing = false;
					}
					// but vote saved ok anyway
					callback(true, hash);
					return;
				}
				// otherwise throw user out of the game
				socket.player_is_playing = false;
				// and tell that vote was not saved - too late
				callback(false, null);
			});

			// player wants to use a live
			socket.on('life', function (callback) {
				// no usage on last question
				if (game_question.game_order > 9) {
					callback(false);
					return;
				}

				if (socket.player.lives_used >= game_settings.game.lives) {
					callback(false);
					return;
				}

				// initially we will trust user and just send confirmation
				// so they do not wait for DB reply
				// bring user back in a game
				socket.player_is_playing = true;
				socket.player_question++;
				socket.player.lives_used++;
				callback(true);

				if (game_lives.hasOwnProperty(game_question.id)) {
					game_lives[game_question.id] = 0;
				}
				game_lives[game_question.id]++;

				// but then we verify with DB and act accordingly
				connection.query('UPDATE players SET lives = lives-1 WHERE lives > 0 AND id=?', [socket.player.id], function (error, results) {
					if (error || results.changedRows < 1) {
						socket.player_is_playing = false;
						socket.emit('life-failure');
						return;
					}
				});
			});

			// player sends a chat message
			socket.on('chat', function (msg) {
				// simply send to all connected users
				if (is_redis) {
					io.local.emit('chat', msg, socket.player);
				} else {
					io.emit('chat', msg, socket.player);
				}
			});

			// update counter on disconnect
			socket.on('disconnect', function () { });
		}
	}
});

function m_settings(settings) {
	console.log(new Date().toUTCString() + ": settings received from moderator.");
	game_settings = settings;
}

function m_start() {
	console.log(new Date().toUTCString() + ": game has started.");
	// game is on
	game_is_on = true;
	// reset a lot of things
	game_question = null;
	game_answers_stats = {};
	game_winners = [];
	game_lives = {};
}

function m_stats() {
	return io.engine.clientsCount > 0 ? io.engine.clientsCount : 0;
}

function m_send_stats() {
	if (game_is_on) {
		if (is_redis) {
			io.of('/').adapter.customRequest({ type: 'stats' }, function (err, replies) {
				if (err)
					console.log('could not get stats from nodes: ' + err);
				else {
					var num = 0;
					for (var i in replies)
						num += replies[i];
					if (num > 0)
						num--;
				}
				io.emit('stats', num);
				analytics.seconds.push(num);
			});
		} else {
			var num = m_stats() - 1;
			io.emit('stats', num);
			analytics.seconds.push(num);
		}
	}
}


function m_question(question, correct, hash) {
	console.log(new Date().toUTCString() + ": question received from moderator: " + question.question);
	//game_question = JSON.parse(JSON.stringify(question));
	game_question = clonedeep(question)
	game_question.hash = hash;
	game_question.asked = new Date();
	game_question.correct = correct;
	game_answers_stats = {};
	for (var i in question.answers) {
		var a = question.answers[i]
		game_answers_stats[a.id] = 0;
	}
}

function m_correct() {
	console.log(new Date().toUTCString() + ": announce correct answer for question " + game_question.question);
	return game_answers_stats;
}

function m_winners() {
	console.log(new Date().toUTCString() + ": announcing winners.");
	return game_winners;
}

function m_stop() {
	// game is off
	game_is_on = false;
}

function m_lives() {
	return game_lives;
}

function m_save_winners(amount, winners) {
	if (game_settings.game.new_week) {
		connection.query("UPDATE players SET total_weekly=0", [], function (error, results) {
			complete();
		});
	} else {
		complete();
	}

	function complete() {
		for (var i = 0; i < winners.length; i++) {
			if (i === winners.length - 1) {
				m_save_winner(amount, winners[i], function () {
					// nullify rank for everyone
					connection.query("UPDATE players SET rank=NULL, rank_weekly=NULL", [], function (error, results) { });
				});
			} else {
				m_save_winner(amount, winners[i], null);
			}
		}
	}
}

function m_save_winner(amount, winner, complete) {
	connection.query('SELECT * FROM game_winner WHERE game_id=? AND player_id=? LIMIT 1', [game_settings.game.id, winner.id], function (error, results) {
		if (error) {
			console.log(new Date().toUTCString() + ": " + error);
			theComplete();
		}
		else if (results.length < 1) {
			connection.query("UPDATE players SET balance = balance + ?, total = total + ?, total_weekly = total_weekly + ? WHERE id=?",
				[amount, amount, amount, winner.id], function (error, results) {
					if (error)
						console.log(error);

					theComplete();

					connection.query("INSERT INTO game_winner(game_id, player_id) VALUES (?,?)", [game_settings.game.id, winner.id], function (error, results) {
						if (error)
							console.log(error);
					});
				});
		} else {
			theComplete();
		}
	});

	function theComplete() {
		if (complete != null) {
			complete();
		}
	}
}

function m_analytics_save() {
	if (is_redis) {
		io.of('/').adapter.customRequest({ type: 'lives' }, function (err, replies) {
			if (err)
				console.log('could not get lives stats from all nodes: ' + err);
			else {
				var the_lives = {};

				for (var j in replies) {
					if (!the_lives.hasOwnProperty(j))
						the_lives[j] = 0;
					the_lives[j] += replies[j];
				}
				addLivesToAnalytics(the_lives);
				doCallback();
			}
		});
	} else {
		addLivesToAnalytics(m_lives());
		doCallback();
	}

	function addLivesToAnalytics(lives) {
		for (var i = 0; i < analytics.questions.length; i++) {
			var qid = analytics.questions[i].question;
			if (lives.hasOwnProperty(qid)) {
				analytics.questions[i].lives = lives[qid];
			}
		}
	}

	function doCallback() {
		connection.query("UPDATE games SET analytics=? WHERE id=?", [JSON.stringify(analytics), game_settings.game.id], function (error, results) {
			if (error)
				console.log(error);
			analytics = {};
		});
	}
}

function m_force_end() {
	var sockets = io.sockets.sockets;
	for (var socketId in sockets) {
		var s = sockets[socketId];
		if (s.player_is_playing) {
			game_winners.push(s.player);
		}
	}
}

/// reconnect load data from DB, players and set player.player_is_playing =  true
function m_reconnect() {
	var sockets = io.sockets.sockets;
	for (var socketId in sockets) {
		var s = sockets[socketId];
		var flag = 0;

		var array = analytics.answered_correctly[game_question.game_order];
		for (var i = 0; i < array.length; i++) {
			if (s.player.id == array[i]) {
				flag = 1;
				break;
			}
		}
		s.player_is_playing = flag == 1;
	}
}

var version = '1.1';
http.listen(port, function () {
	console.log('Version: ' + version);
	console.log(new Date().toUTCString() + ': Server listening at port %d', port);
});
